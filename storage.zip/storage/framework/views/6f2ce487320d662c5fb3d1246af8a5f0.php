<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola pengguna - Coffee Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/staff.css')); ?>" rel="stylesheet">
    <style>
        body { background: #f7f7f5; color: #252525; font-family: Inter, 'Segoe UI', sans-serif; }
        .panel, .topbar { background: #fff; border: 1px solid #ecebe7; border-radius: 12px; }
        .btn-accent { background: #bd5b28; border-color: #bd5b28; color: #fff; }
        .btn-accent:hover { background: #a64b20; border-color: #a64b20; color: #fff; }
        .modal-content { border: 1px solid #ecebe7; border-radius: 16px; }
    </style>
</head>
<body>
<main class="container py-4 py-lg-5">
    <header class="topbar p-3 p-md-4 d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
            <div class="text-uppercase small fw-semibold" style="color:#bd5b28">Coffee Shop</div>
            <h1 class="h4 fw-bold mb-1">Kelola pengguna</h1>
            <p class="text-secondary small mb-0">Atur akun yang dapat masuk sebagai admin atau kasir</p>
        </div>
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-accent btn-sm">Tambah pengguna</a>
        <div class="w-100"><?php echo $__env->make('admin.partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
    </header>

    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if(session('warning')): ?><div class="alert alert-warning"><?php echo e(session('warning')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><?php echo e($errors->first()); ?></div><?php endif; ?>
    <?php if(config('mail.default') !== 'smtp' || !config('mail.mailers.smtp.username') || !config('mail.mailers.smtp.password') || !config('mail.from.address')): ?>
        <div class="alert alert-info small">SMTP Gmail sudah disiapkan. Isi MAIL_USERNAME dengan alamat Gmail pengirim dan MAIL_PASSWORD dengan app password Gmail di .env Laragon. MAIL_FROM_ADDRESS mengikuti MAIL_USERNAME. Setelah mengubah .env, jalankan php artisan config:clear.</div>
    <?php endif; ?>

    <section class="panel p-3 p-md-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light small"><tr><th>Nama</th><th>Email</th><th>Role</th><th class="text-end">Aksi</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="fw-semibold"><?php echo e($user->name); ?> <?php if($user->id === auth()->id()): ?><span class="badge text-bg-light">Akun Anda</span><?php endif; ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><span class="badge <?php echo e($user->role === 'admin' ? 'text-bg-dark' : 'text-bg-secondary'); ?>"><?php echo e(ucfirst($user->role)); ?></span></td>
                        <td>
                            <div class="d-flex justify-content-end gap-2">
                                <form action="<?php echo e(route('admin.users.notify', $user)); ?>" method="POST"><?php echo csrf_field(); ?><button class="btn btn-outline-secondary btn-sm">Kirim email</button></form>
                                <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#edit-user-<?php echo e($user->id); ?>">Ubah</button>
                                <?php if($user->id !== auth()->id()): ?>
                                    <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST" onsubmit="return confirm('Hapus akun <?php echo e(addslashes($user->name)); ?>?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-outline-danger btn-sm">Hapus</button></form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="text-center text-secondary py-4">Belum ada akun admin atau kasir.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $editingThisUser = (string) request('edit_user') === (string) $user->id; ?>
        <div class="modal fade" id="edit-user-<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="edit-user-title-<?php echo e($user->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="modal-header border-0 pb-0">
                            <div>
                                <h2 class="modal-title h5 fw-bold" id="edit-user-title-<?php echo e($user->id); ?>">Ubah pengguna</h2>
                                <p class="small text-secondary mb-0">Perbarui informasi akun <?php echo e($user->name); ?></p>
                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="name-<?php echo e($user->id); ?>" class="form-label small">Nama</label>
                                <input id="name-<?php echo e($user->id); ?>" name="name" class="form-control" value="<?php echo e($editingThisUser ? old('name', $user->name) : $user->name); ?>" required maxlength="255">
                            </div>
                            <div class="mb-3">
                                <label for="email-<?php echo e($user->id); ?>" class="form-label small">Email login</label>
                                <input id="email-<?php echo e($user->id); ?>" name="email" type="email" class="form-control" value="<?php echo e($editingThisUser ? old('email', $user->email) : $user->email); ?>" required maxlength="255">
                            </div>
                            <div class="mb-3">
                                <label for="role-<?php echo e($user->id); ?>" class="form-label small">Role</label>
                                <select id="role-<?php echo e($user->id); ?>" name="role" class="form-select" required>
                                    <option value="kasir" <?php echo e(($editingThisUser ? old('role', $user->role) : $user->role) === 'kasir' ? 'selected' : ''); ?>>Kasir</option>
                                    <option value="admin" <?php echo e(($editingThisUser ? old('role', $user->role) : $user->role) === 'admin' ? 'selected' : ''); ?>>Admin</option>
                                </select>
                                <?php if($user->id === auth()->id()): ?><div class="form-text">Role akun yang sedang digunakan tidak dapat diturunkan.</div><?php endif; ?>
                            </div>
                            <div class="mb-3">
                                <label for="password-<?php echo e($user->id); ?>" class="form-label small">Password baru (opsional)</label>
                                <input id="password-<?php echo e($user->id); ?>" name="password" type="password" class="form-control" minlength="8" autocomplete="new-password">
                                <div class="form-text">Biarkan kosong jika tidak ingin mengganti password.</div>
                            </div>
                            <div>
                                <label for="password-confirmation-<?php echo e($user->id); ?>" class="form-label small">Konfirmasi password baru</label>
                                <input id="password-confirmation-<?php echo e($user->id); ?>" name="password_confirmation" type="password" class="form-control" minlength="8" autocomplete="new-password">
                            </div>
                        </div>
                        <div class="modal-footer border-0 pt-0">
                            <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-accent btn-sm">Simpan perubahan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const editUserId = new URLSearchParams(window.location.search).get('edit_user');
    if (editUserId) {
        const editModal = document.getElementById(`edit-user-${editUserId}`);
        if (editModal) bootstrap.Modal.getOrCreateInstance(editModal).show();
    }
</script>
</body>
</html>
<?php /**PATH C:\laragon\www\ta bina\qr-order\resources\views/admin/users/index.blade.php ENDPATH**/ ?>