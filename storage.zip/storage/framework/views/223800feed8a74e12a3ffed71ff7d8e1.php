<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Verifikasi Pembayaran - Coffee Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/staff.css')); ?>" rel="stylesheet">
    <style>body{background:#f7f7f5;color:#252525;font-family:Inter,'Segoe UI',sans-serif}.panel,.topbar{background:#fff;border:1px solid #ecebe7;border-radius:12px}.btn-accent{background:#bd5b28;color:#fff}.btn-accent:hover{background:#a64b20;color:#fff}</style>
</head>
<body><main class="container py-4 py-lg-5">
    <header class="topbar p-3 p-md-4 d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div><div class="text-uppercase small fw-semibold" style="color:#bd5b28">Coffee Shop</div><h1 class="h4 fw-bold mb-1">Verifikasi pembayaran</h1><p class="text-secondary small mb-0"><?php echo e($pesananMenunggu->count()); ?> pembayaran menunggu konfirmasi</p></div>
        <div class="w-100"><?php echo $__env->make('admin.partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
    </header>
    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><?php echo e($errors->first()); ?></div><?php endif; ?>
    <section class="row g-3">
        <?php $__empty_1 = true; $__currentLoopData = $pesananMenunggu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $metode=strtolower($order->metode_pembayaran ?? $order->payment_method ?? ''); $total=$order->total_harga ?? $order->total ?? $order->total_amount; ?>
            <div class="col-lg-6"><article class="panel p-3 p-md-4 h-100">
                <div class="d-flex justify-content-between gap-3 mb-3"><div><h2 class="h6 fw-bold mb-1">Pesanan #<?php echo e($order->id); ?></h2><div class="small text-secondary"><?php echo e($order->nama_pemesan ?? $order->customer_name); ?> · Meja <?php echo e($order->nomor_meja ?? $order->table_id); ?></div><div class="small text-secondary"><?php echo e($order->created_at->format('d M Y, H:i')); ?></div></div><span class="badge text-bg-warning align-self-start">Menunggu</span></div>
                <div class="border-top border-bottom py-2 mb-3 small"><?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="d-flex justify-content-between"><span><?php echo e($det->quantity ?? $det->qty ?? 1); ?>x <?php echo e($det->menu->nama_menu ?? 'Menu'); ?></span><span>Rp <?php echo e(number_format($det->subtotal ?? 0,0,',','.')); ?></span></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
                <div class="d-flex justify-content-between fw-semibold mb-3"><span>Total tagihan</span><span>Rp <?php echo e(number_format($total,0,',','.')); ?></span></div>
                <form action="<?php echo e(route('admin.order.status',$order->id)); ?>" method="POST" class="d-flex flex-wrap align-items-end gap-2 mb-3 p-3 rounded-3" style="background:#f7f7f5"><?php echo csrf_field(); ?><div class="flex-grow-1"><label class="form-label small mb-1" for="status-<?php echo e($order->id); ?>">Status pesanan</label><select id="status-<?php echo e($order->id); ?>" name="status" class="form-select form-select-sm"><option value="pending" <?php echo e($order->status==='pending'?'selected':''); ?>>Menunggu</option><option value="diproses" <?php echo e($order->status==='diproses'?'selected':''); ?>>Diproses</option><option value="selesai" <?php echo e($order->status==='selesai'?'selected':''); ?>>Selesai</option></select></div><button class="btn btn-outline-secondary btn-sm">Ubah status</button></form>
                <?php if(in_array($metode,['tunai','cash'],true)): ?>
                    <form action="<?php echo e(route('admin.order.bayarTunai',$order->id)); ?>" method="POST" class="row g-2 align-items-end"><?php echo csrf_field(); ?><div class="col"><label class="form-label small" for="jumlah-<?php echo e($order->id); ?>">Jumlah uang diterima</label><input id="jumlah-<?php echo e($order->id); ?>" type="number" name="jumlah_bayar" min="<?php echo e($total); ?>" step="1" class="form-control form-control-sm" placeholder="Masukkan nominal" required></div><div class="col-auto"><button class="btn btn-accent btn-sm">Konfirmasi tunai</button></div></form>
                <?php else: ?>
                    <form action="<?php echo e(route('admin.order.verifikasi',$order->id)); ?>" method="POST" class="d-flex flex-wrap gap-2"><?php echo csrf_field(); ?><button name="status_verifikasi" value="verified" class="btn btn-success btn-sm">Konfirmasi pembayaran</button><button name="status_verifikasi" value="rejected" class="btn btn-outline-danger btn-sm">Tolak</button></form>
                <?php endif; ?>
            </article></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12"><div class="panel text-center text-secondary p-5">Tidak ada pembayaran yang menunggu verifikasi.</div></div>
        <?php endif; ?>
    </section>
</main></body>
</html>
<?php /**PATH C:\laragon\www\ta bina\qr-order\resources\views/admin/pembayaran.blade.php ENDPATH**/ ?>