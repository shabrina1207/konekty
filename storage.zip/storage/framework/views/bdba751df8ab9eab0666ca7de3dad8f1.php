<nav class="app-navigation" aria-label="Navigasi staf">
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="staff-nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" <?php if(request()->routeIs('admin.dashboard')): ?> aria-current="page" <?php endif; ?>>Dashboard</a>
    <a href="<?php echo e(route('admin.pembayaran')); ?>" class="staff-nav-link <?php echo e(request()->routeIs('admin.pembayaran') ? 'active' : ''); ?>" <?php if(request()->routeIs('admin.pembayaran')): ?> aria-current="page" <?php endif; ?>>Pembayaran</a>
    <a href="<?php echo e(route('admin.rekap', ['periode' => 'bulanan'])); ?>" class="staff-nav-link <?php echo e(request()->routeIs('admin.rekap*') ? 'active' : ''); ?>" <?php if(request()->routeIs('admin.rekap*')): ?> aria-current="page" <?php endif; ?>>Rekap penjualan</a>
    <?php if(auth()->user()->role === 'admin'): ?>
        <a href="<?php echo e(route('admin.menus.index')); ?>" class="staff-nav-link <?php echo e(request()->routeIs('admin.menus.*') ? 'active' : ''); ?>" <?php if(request()->routeIs('admin.menus.*')): ?> aria-current="page" <?php endif; ?>>Kelola menu</a>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="staff-nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>" <?php if(request()->routeIs('admin.users.*')): ?> aria-current="page" <?php endif; ?>>Kelola pengguna</a>
    <?php endif; ?>
    <form action="<?php echo e(route('logout')); ?>" method="POST" class="staff-nav-logout"><?php echo csrf_field(); ?><button class="staff-nav-link" type="submit">Keluar</button></form>
</nav>
<?php /**PATH C:\laragon\www\ta bina\qr-order\resources\views/admin/partials/navigation.blade.php ENDPATH**/ ?>