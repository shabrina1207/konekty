<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Kasir - Coffee Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; height: 100vh; display: flex; align-items: center; justify-content: center; }
        .card-login { width: 100%; max-width: 400px; border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
        .btn-orange { background-color: #ff6b00; color: white; font-weight: 600; border-radius: 20px; }
        .btn-orange:hover { background-color: #e56000; color: white; }
    </style>
</head>
<body>

<div class="card card-login p-4 bg-white">
    <div class="text-center mb-4">
        <h4 class="fw-bold mb-1">COFFEE SHOP</h4>
        <p class="text-muted small">Silakan masuk ke akun kasir</p>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger py-2 small text-center">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('login.process')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label text-muted small">Username</label>
            <input type="text" name="username" class="form-control" value="kasir" required>
        </div>
        <div class="mb-4">
            <label class="form-label text-muted small">Password</label>
            <input type="password" name="password" class="form-control" value="123456" required>
        </div>
        <button type="submit" class="btn btn-orange w-100 py-2">Masuk Dashboard</button>
    </form>
</div>

</body>
</html><?php /**PATH /workspaces/tugas-akhir/qr-order/resources/views/auth/login.blade.php ENDPATH**/ ?>